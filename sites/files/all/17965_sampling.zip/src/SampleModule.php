<?php

namespace modules\custom\sampling\src;

class SampleModule
{

}