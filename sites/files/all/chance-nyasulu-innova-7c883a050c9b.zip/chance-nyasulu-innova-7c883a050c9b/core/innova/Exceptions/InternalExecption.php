<?php

namespace Innova\Exceptions;

class InternalExecption extends \Exception
{
}