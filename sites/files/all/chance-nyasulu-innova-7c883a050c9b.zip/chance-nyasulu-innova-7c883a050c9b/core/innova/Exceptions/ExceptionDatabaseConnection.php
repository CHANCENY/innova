<?php

namespace Innova\Exceptions;

class ExceptionDatabaseConnection extends \Exception
{
}