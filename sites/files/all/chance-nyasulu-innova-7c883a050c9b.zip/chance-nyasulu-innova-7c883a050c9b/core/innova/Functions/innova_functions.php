<?php

use Innova\Exceptions\InternalExecption;
use JetBrains\PhpStorm\NoReturn;

function dd(...$data): void
{
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    exit;
}

function active_controller(): \Innova\Routes\Routes
{
    global $route_object;
    return $route_object;
}


#[NoReturn] function exceptions(\Throwable $throwable): void
{
    /**
     * handle all exception happening in our site
     */
    $data = base64_encode(serialize($throwable));
    $file_name = "error_". random_int(0, 100000) . ".txt";
    if(!is_dir("sites/settings/application/errors")){
        mkdir("sites/settings/application/errors", 7777,true);
    }
    file_put_contents("sites/settings/application/errors/$file_name", $data);
    echo "<p>Unexpected error encountered</p>";
    exit;
}

$errorSetting = \Innova\Configs\ConfigHandler::config("error_setting");
if(!empty($errorSetting['enabled']) && $errorSetting['enabled'] === "on")
{
    set_exception_handler('exceptions');
}

/**
 * @param $datetime
 * @param bool $full
 * @return string|void
 * @throws Exception
 */
function ago($datetime, bool $full = false )
{
    $now = new \DateTime;
    $ago = new \DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}


function dateFormat(string $datetime, string $format): string
{
    try {
        return (new DateTime($datetime))->format($format);
    }catch (Throwable $throwable)
    {
        return $datetime;
    }
}


function changeGlobals(): array
{
    /**
     * Make func for change necessary
     */
    $scriptFilename = $_SERVER['SCRIPT_NAME'];
    $listingFileComponents = explode("/", $scriptFilename);
    $array = [];
    if ( count($listingFileComponents) >= 3 ) {
        $array['home'] = $listingFileComponents[1];
    }
    //TODO more changes
    return $array;
}


function formatBytes($bytes, $precision = 2): string
{
    $units = array('B', 'KB', 'MB', 'GB', 'TB');

    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
     $bytes /= (1 << (10 * $pow));

    return round($bytes, $precision) . $units[$pow];
}