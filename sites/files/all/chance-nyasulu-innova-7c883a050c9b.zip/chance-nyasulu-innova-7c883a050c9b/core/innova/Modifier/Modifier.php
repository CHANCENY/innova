<?php

namespace Innova\Modifier;

use Innova\request\Request;

/**
 * This class is for modifying global variables of page content
 * It is class if you want to modified some global keys eg title
 */

class Modifier
{
    /**
     *
     */
    const TYPE = [
        1 => "css",
        2 => "js"
    ];

    /**
     *
     */
    const SECTION = [
        1 => "head",
        2 => "footer"
    ];

    /**
     * @param string $title
     * @param bool $appendDomain
     * @param $joinBy
     * @return void
     */
    public static function setTitle(string $title, bool $appendDomain = false, $joinBy = " | "): void
    {
        global $head_section;
        $title = htmlspecialchars(strip_tags($title));
        if($appendDomain)
        {
            $title = $title . $joinBy . (new Request())->domain();
        }
        $head_section['title'] = $title;
    }

    /**
     * @param string $library
     * @param int $type
     * @param int $section
     * @return void
     */
    public static function setLibrary(string $library, int $type = 1, int $section = 1): void
    {
        global $head_section;
        global $footer_section;

        if(self::SECTION[$section] === "head")
        {
            if(self::TYPE[$type] === "js")
            {
                $head_section['library']['js'][] = $library;
            }
            if(self::TYPE[$type] === "css")
            {
                $head_section['library']['css'][] = $library;
            }
        }

        if(self::SECTION[$section] === "footer")
        {
            if(self::TYPE[$type] === "js")
            {
                $footer_section['footer_outer']['library']['js'][] = $library;
            }
            if(self::TYPE[$type] === "css")
            {
                $footer_section['footer_outer']['library']['css'][] = $library;
            }
        }
    }

    /**
     * @param string $name
     * @param $value
     * @return void
     */
    public static function setMetaTags(string $name, $value): void
    {
        global $head_section;
        $head_section['meta'][] = ['name'=>$name, "value"=>$value];
    }
}