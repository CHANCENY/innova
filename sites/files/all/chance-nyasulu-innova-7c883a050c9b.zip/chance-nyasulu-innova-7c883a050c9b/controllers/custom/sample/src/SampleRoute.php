<?php 
namespace Innova\Controller\Custom\sample\src; 


class SampleRoute 
{ 


public function page(): mixed { return 'Welcome Sample Route';}


}