<?php

use Innova\Modifier\Modifier;

function homepage_head_sections(): void
{
    Modifier::setTitle("Welcome", true);
    //Modifier::setMetaTags("description", "This is user profile page for Innova framework");

}
