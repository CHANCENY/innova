<?php

use Innova\Modifier\Modifier;

function routing_head_sections(): void
{
    //Modifier::setTitle("User {$_GET['user_id']}", true);
    //Modifier::setMetaTags("description", "This is user profile page for Innova framework");
}
