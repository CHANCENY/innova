<?php 
namespace Innova\Controller\routers\sample\src; 


class SampleTwo 
{ 


public function page(): mixed { return 'Welcome Sample two';}


}