<?php 
namespace Innova\Controller\routers\sample\src; 


class Sample 
{ 


public function page(): mixed { return 'Welcome Sample';}


}