<?php

use Innova\Modifier\Modifier;

function installation_head_sections(): void
{
}
