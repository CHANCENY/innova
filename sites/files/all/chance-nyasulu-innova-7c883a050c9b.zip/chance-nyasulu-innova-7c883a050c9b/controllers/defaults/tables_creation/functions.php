<?php

use Innova\Modifier\Modifier;

function tables_creation_head_sections(): void
{
}
