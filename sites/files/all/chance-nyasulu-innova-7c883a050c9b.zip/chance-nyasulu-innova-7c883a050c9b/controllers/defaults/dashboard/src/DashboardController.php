<?php

namespace Innova\Controller\routers\dashboard\src;

use Innova\modules\CurrentUser;
use Innova\modules\Site;
use Innova\Templates\TemplatesHandler;

class DashboardController extends Site
{
    public function innovaDashboard(): mixed
    {
        $data['firstname'] = (new CurrentUser())->firstname();
        return TemplatesHandler::view("dashboard/dashboard.php", $data, true);
    }
}