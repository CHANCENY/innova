<?php 
namespace Innova\Controller\routers\users\src; 


class UserEdit 
{ 


public function page(): mixed { return 'Welcome User Edit';}


}