<?php

namespace Innova\Controller\routers\users\src;

use Innova\modules\CurrentUser;
use Innova\modules\Forms;
use Innova\modules\Messager;
use Innova\modules\Site;
use Innova\request\Request;
use Innova\Templates\TemplatesHandler;

class UserLoginController extends Site
{
    public function userLoginForm(): mixed
    {
        global $middle;
        $data = [
            'logo'=>self::logo(),
            'middle'=>$middle,
            "current_url"=> (new Request())->httpSchema(). "/users/sign-in",
            "msg"=>null
            ];

        if((new Request())->method() === "post")
        {
            if($this->loginUser(new Request()))
            {
                $firstname = (new CurrentUser())->firstname();
                Messager::message()->addMessage("Welcome $firstname to @site", ['@site'=>$this->siteName()]);
                if((new CurrentUser())->isAdmin())
                {
                    (new Request())->redirection('/', true);
                }
                else
                {
                    (new Request())->redirection('/');
                }
            }else{
                $data['msg'] = <<<ALERT
<div class="alert alert-warning alert-dismissible fade show" role="alert">
								Username or EmailAddress or Password is invalid. 
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
ALERT;
            }
        }
        return TemplatesHandler::view("user_login/form.php", $data, isDefaultView: true);
    }

    private function loginUser(Request $request): bool
    {
        return Forms::login($request->post("username"), $request->post("password"));
    }
}