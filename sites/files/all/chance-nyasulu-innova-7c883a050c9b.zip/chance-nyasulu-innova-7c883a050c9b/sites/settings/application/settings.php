<?php
/**
 * Setting file have being made to give user access to some of php.ini
 * settings
 */

ini_set ('display_errors', 1);
ini_set ('display_startup_errors', 1);
error_reporting (E_ALL);



