<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">Welcome to Innova <?php $firstname; ?></h4>
            </div>
        </div>
    </div>
</div>