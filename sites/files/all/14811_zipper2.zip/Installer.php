<?php

namespace Innova\modules;

use Innova\Exceptions\InstallException;
use Ramsey\Uuid\Uuid;

class Installer {

  public function __construct(
    private string $zip,
    private bool $isModule = true,
    private bool $isLibrary = false
  ) {
    if($this->isModule === $this->isLibrary) {
      throw new InstallException("Installation type conflict. do you want to install module or library");
    }
  }
  public function installModule(): Installer
  {
    if(!file_exists($this->zip)) {
      throw new InstallException("Zip path provided not found");
    }

    $temporary = "sites/files/temp/". random_int(0, 900);
    if(!is_dir($temporary)) {
      mkdir($temporary, 7777, true);
    }

    up:
    $moduleName = $temporary. "/module_" . random_int(0, 900);
    if(is_dir($moduleName)) {
      goto up;
    }

    mkdir($moduleName, 7777 , true);

    // Extract zip file and check for requirements.
    if(!Zipper::extract($this->zip,$moduleName)) {
      throw new InstallException("Failed to unzip your module in $moduleName");
    }

    $listContent = array_diff(scandir($moduleName),['.', '..', '...']);

    //requirement
    //module requires src/
    //namespace always will start with modules/custom/module-name/src/php files
    //on root will need module-name.info.json file containing
    // {"name": "module-name", "description": "module-description"}

    //module structure
     //module-name/src/
    //module-name/module-name.info.json

    //looking for module.json
    $moduleJson = $moduleName . "/" . $listContent[array_search(".info.json",$listContent)];
    if(!file_exists($moduleJson) || !str_ends_with($moduleJson, ".info.json")){
      throw new InstallException(".info.json file not found at root of your module");
    }

    $content = json_decode(file_get_contents($moduleJson, true));
    $moduleRoot = $content['name'] ?? null;
    if(empty($moduleRoot) || strpos($moduleRoot, " ")){
      throw new InstallException("Check your module name either not found or name has space");
    }

    $modulePath = "modules/custom/$moduleRoot";
    if(is_dir($modulePath)) {
      throw new InstallException("Module will this name ($moduleRoot) already exist");
    }

    mkdir($modulePath, 7777, true);

    $source = $moduleName . "/src";
    if(!is_dir($source)) {
      throw new InstallException("Module src folder not found");
    }

    if(Zipper::extract($this->zip, $modulePath)){
      $content['module_id'] = Uuid::uuid4()->toString();
      file_put_contents($moduleJson,json_encode($content,JSON_PRETTY_PRINT));
    }

    //zip from temp to all
    $zip = new Zipper($moduleName);
    $file  = $zip->compressDirectory($temporary);

    //save this to all and record in file_managed.
    return $this;
  }

}