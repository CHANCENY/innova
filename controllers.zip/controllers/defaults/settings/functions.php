<?php

function settings_head_sections(): void
{
}