<?php

use Innova\Modifier\Modifier;

function databases_head_sections(): void
{
}
