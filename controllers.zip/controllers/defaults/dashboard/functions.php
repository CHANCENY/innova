<?php

function dashboard_head_sections(array &$heads): void
{
//  $content = new \Innova\Content\ContentType();
//  $content->create("Blogs");
//  $name = $content->machineName;
//
//  if(!empty($name))
//  {
//    $fields = new \Innova\Content\Fields($name);
//    $fields->addField(
//      [
//        [
//          "type" => "text",
//          "label" => "Category",
//          "description" => "Category of articles",
//          "storage_type" => "short text"
//        ],
//        [
//          "type" => "text",
//          "label" => "Body",
//          "description" => "Article content in html",
//          "storage_type" => "long text"
//        ],
//        [
//          "type" => "file",
//          "label" => "Blog Image",
//          "description" => "Blog image content in html",
//          "storage_type" => "number"
//        ]
//      ]
//    )->saveFields();
//
//    $pers = new \Innova\Content\PersistStorage($name);
//    $pers->persistContent();
//  }
}

function dashboard_body_sections(array &$body): void
{

}

