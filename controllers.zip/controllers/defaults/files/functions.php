<?php

use Innova\Modifier\Modifier;
use Innova\modules\Site;

function files_head_sections(): void
{
}