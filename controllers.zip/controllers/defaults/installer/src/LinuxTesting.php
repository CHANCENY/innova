<?php 
namespace Innova\Controller\routers\installer\src; 


class LinuxTesting 
{ 


public function page(): mixed { return 'Welcome Linux Testing';}


}