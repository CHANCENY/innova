<?php 
namespace Innova\Controller\Custom\linux\src; 


class LinuxTesting 
{ 


public function page(): mixed { return 'Welcome Linux Testing';}


}