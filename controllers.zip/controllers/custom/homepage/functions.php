<?php

use Innova\Modifier\Modifier;
use Innova\Sessions\Session;

function homepage_head_sections(): void
{

}
