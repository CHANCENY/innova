<?php 
namespace Innova\Controller\Custom\sampling\src; 


class CustomSampling 
{ 


public function page(): mixed { return 'Welcome Custom Sampling';}


}