<?php

namespace Innova\MailManger;

class ParamMissingException extends \Exception {
}