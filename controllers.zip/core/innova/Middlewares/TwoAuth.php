<?php

namespace Innova\Middlewares;

class TwoAuth extends TwoAuthentication {

}