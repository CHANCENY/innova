<?php

namespace Innova\Middlewares;

class PassLess extends PasswordLess {

}