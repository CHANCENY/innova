<?php

namespace Innova\Middlewares;

class Auth extends Authentications
{

}