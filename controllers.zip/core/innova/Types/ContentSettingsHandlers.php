<?php

namespace Innova\Types;

class ContentSettingsHandlers
{

}