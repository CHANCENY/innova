<?php

namespace Innova\Abstracted;

class DashboardClass
{

}