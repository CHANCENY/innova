<?php

namespace Innova\Exceptions;

class InstallException extends \Exception
{

}