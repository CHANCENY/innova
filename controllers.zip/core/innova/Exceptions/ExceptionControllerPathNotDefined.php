<?php

namespace Innova\Exceptions;

class ExceptionControllerPathNotDefined extends \Exception
{
}