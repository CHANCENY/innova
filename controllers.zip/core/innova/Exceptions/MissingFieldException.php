<?php

namespace Innova\Exceptions;

class MissingFieldException extends \Exception
{
}