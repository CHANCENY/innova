<?php

namespace Innova\Exceptions;

class ExceptionControllerNotExist extends \Exception
{
}