<?php

namespace Innova\Exceptions;

class ZipperException extends \Exception
{
}